
package modelo;

/**
 *
 * @author AndresSossa
 */
public class TIPO_DE_DOCUMENTO_CONTABLE {
    
    private String id_tipo_de_documento_contable;
    private String descripcion;
    private String naturaleza;

    public String getId_tipo_de_documento_contable() {
        return id_tipo_de_documento_contable;
    }

    public void setId_tipo_de_documento_contable(String id_tipo_de_documento_contable) {
        this.id_tipo_de_documento_contable = id_tipo_de_documento_contable;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getNaturaleza() {
        return naturaleza;
    }

    public void setNaturaleza(String naturaleza) {
        this.naturaleza = naturaleza;
    }
    
  
}
