package adicionalescar;

import java.util.List;

public interface CategoryDao {

	void save(Category category);

	List<Category> findAll();

	Category findByName(String categoryName);

	void deleteByName(String categoryName);

	Category findOne(String categoryId);
	

}
