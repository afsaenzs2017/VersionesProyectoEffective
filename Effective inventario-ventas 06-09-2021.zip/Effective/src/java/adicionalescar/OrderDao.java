package adicionalescar;

import java.util.List;

public interface OrderDao {

	void save(Order order);

	Order findByNum(String ordernum);

	void update(Order order);

	List<Order> findByCustomerId(String customerId);

	
	List<OrderItem> findOrderItem(String ordernum);

}
