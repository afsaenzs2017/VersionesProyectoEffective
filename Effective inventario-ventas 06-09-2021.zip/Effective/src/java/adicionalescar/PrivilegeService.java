package adicionalescar;

import java.util.List;

public interface PrivilegeService {

	User login(String username, String password);
	List<Role> findUserRoles(User user);

	List<Function> findRoleFunctions(Role role);


}
