
package modelo;

/**
 *
 * @author YesidValencia
 */
public class UNIDAD_DE_MEDIDA_PRODUCTO {
    
    private String id_unidad_de_medida_producto;
    private String descripcion_unidad_de_medida_producto;

    public String getId_unidad_de_medida_producto() {
        return id_unidad_de_medida_producto;
    }

    public void setId_unidad_de_medida_producto(String id_unidad_de_medida_producto) {
        this.id_unidad_de_medida_producto = id_unidad_de_medida_producto;
    }

    public String getDescripcion_unidad_de_medida_producto() {
        return descripcion_unidad_de_medida_producto;
    }

    public void setDescripcion_unidad_de_medida_producto(String descripcion_unidad_de_medida_producto) {
        this.descripcion_unidad_de_medida_producto = descripcion_unidad_de_medida_producto;
    }
    
    

   
    
}
