package modelo;

/**
 *
 * @author AndresSaenz
 */
public class GENERO_USUARIO {

    private String id_genero_usuario;
    private String descripcion_genero_usuario;

    public String getId_genero_usuario() {
        return id_genero_usuario;
    }

    public void setId_genero_usuario(String id_genero_usuario) {
        this.id_genero_usuario = id_genero_usuario;
    }

    public String getDescripcion_genero_usuario() {
        return descripcion_genero_usuario;
    }

    public void setDescripcion_genero_usuario(String descripcion_genero_usuario) {
        this.descripcion_genero_usuario = descripcion_genero_usuario;
    }

}
