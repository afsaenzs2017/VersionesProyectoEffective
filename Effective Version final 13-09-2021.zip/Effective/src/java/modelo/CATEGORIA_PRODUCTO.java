package modelo;

/**
 *
 * @author YesidValencia
 */
public class CATEGORIA_PRODUCTO {

    private String id_categoria_producto;
    private String nombre_categoria_producto;

    public String getId_categoria_producto() {
        return id_categoria_producto;
    }

    public void setId_categoria_producto(String id_categoria_producto) {
        this.id_categoria_producto = id_categoria_producto;
    }

    public String getNombre_categoria_producto() {
        return nombre_categoria_producto;
    }

    public void setNombre_categoria_producto(String nombre_categoria_producto) {
        this.nombre_categoria_producto = nombre_categoria_producto;
    }

}
