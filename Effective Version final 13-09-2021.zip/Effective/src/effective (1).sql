-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 12-09-2021 a las 05:21:27
-- Versión del servidor: 10.4.20-MariaDB
-- Versión de PHP: 8.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `effective`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categoria_producto`
--

CREATE TABLE `categoria_producto` (
  `id_categoria_producto` int(11) NOT NULL,
  `nombre_categoria_producto` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `categoria_producto`
--

INSERT INTO `categoria_producto` (`id_categoria_producto`, `nombre_categoria_producto`) VALUES
(1, 'Cuadernos'),
(2, 'Lapiceros'),
(3, 'Lapices'),
(4, 'Marcadores'),
(5, 'Pinturas'),
(6, 'Folder');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clientes`
--

CREATE TABLE `clientes` (
  `idCliente` int(11) NOT NULL,
  `nombreCliente` varchar(45) NOT NULL,
  `apellidoCliente` varchar(45) NOT NULL,
  `correoCliente` varchar(45) DEFAULT NULL,
  `telefonoCliente` varchar(45) NOT NULL,
  `direccionCliente` varchar(45) NOT NULL,
  `identificacionCliente` varchar(45) NOT NULL,
  `USUARIOS_id_usuario` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `clientes`
--

INSERT INTO `clientes` (`idCliente`, `nombreCliente`, `apellidoCliente`, `correoCliente`, `telefonoCliente`, `direccionCliente`, `identificacionCliente`, `USUARIOS_id_usuario`) VALUES
(1, 'Luis', 'Cubero', '', '11', '11', '23', 4),
(2, 'Maya', 'Arias', 'a@a.com', '2', '2', '24', 5),
(3, 'Prueba', 'Prueba', 'a@a.com', '1', '1', '111', 4);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalle_movimiento`
--

CREATE TABLE `detalle_movimiento` (
  `id_detalle_movimiento` int(11) NOT NULL,
  `cantidad` int(3) NOT NULL,
  `precio_productos` float DEFAULT NULL,
  `subtotal_productos` float NOT NULL,
  `iva_productos` float NOT NULL,
  `total_productos` float NOT NULL,
  `PRODUCTOS_id_producto` int(10) UNSIGNED ZEROFILL NOT NULL,
  `MOVIMIENTO_id_movimiento` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `detalle_movimiento`
--

INSERT INTO `detalle_movimiento` (`id_detalle_movimiento`, `cantidad`, `precio_productos`, `subtotal_productos`, `iva_productos`, `total_productos`, `PRODUCTOS_id_producto`, `MOVIMIENTO_id_movimiento`) VALUES
(62, 500, 0, 0, 0, 0, 0000000012, 54),
(63, 100, 0, 0, 0, 0, 0000000013, 55),
(64, 100, 0, 0, 0, 0, 0000000014, 56),
(65, 10, 0, 0, 0, 0, 0000000015, 57),
(69, 25, 0, 0, 0, 0, 0000000016, 60),
(70, 25, 0, 0, 0, 0, 0000000017, 61),
(71, 2, 35000, 64814.8, 5185.19, 70000, 0000000017, 62),
(72, 10, 15000, 126050, 23949.6, 150000, 0000000013, 62),
(73, 1, 25000, 21008.4, 3991.6, 25000, 0000000014, 63),
(74, 1, 23000, 19327.7, 3672.27, 23000, 0000000015, 63),
(75, 1, 5000, 4201.68, 798.319, 5000, 0000000012, 63);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estado_producto`
--

CREATE TABLE `estado_producto` (
  `id_estado_producto` int(11) NOT NULL,
  `descripcion_estado_producto` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `estado_producto`
--

INSERT INTO `estado_producto` (`id_estado_producto`, `descripcion_estado_producto`) VALUES
(1, 'Activo'),
(2, 'Inactivo');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estado_usuario`
--

CREATE TABLE `estado_usuario` (
  `id_estado_usuario` int(11) NOT NULL,
  `descripcion_estado_usuario` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `estado_usuario`
--

INSERT INTO `estado_usuario` (`id_estado_usuario`, `descripcion_estado_usuario`) VALUES
(1, 'Actiivo'),
(2, 'Inactivo');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `formas_de_pago`
--

CREATE TABLE `formas_de_pago` (
  `id_forma_de_pago` int(11) NOT NULL,
  `tipo_de_pago` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `formas_de_pago`
--

INSERT INTO `formas_de_pago` (`id_forma_de_pago`, `tipo_de_pago`) VALUES
(1, 'Efectivo'),
(2, 'Cheque'),
(3, 'Tarjeta');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `genero_usuario`
--

CREATE TABLE `genero_usuario` (
  `id_genero_usuario` int(11) NOT NULL,
  `descripcion_genero_usuario` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `genero_usuario`
--

INSERT INTO `genero_usuario` (`id_genero_usuario`, `descripcion_genero_usuario`) VALUES
(1, 'Masculino'),
(2, 'Femenino');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `inventario`
--

CREATE TABLE `inventario` (
  `id_inventario` int(11) NOT NULL,
  `entradas` int(10) DEFAULT NULL,
  `salidas` int(10) DEFAULT NULL,
  `saldo` int(10) DEFAULT NULL,
  `PRODUCTOS_id_producto` int(10) UNSIGNED ZEROFILL NOT NULL,
  `DETALLE_MOVIMIENTO_id_detalle_movimiento` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `inventario`
--

INSERT INTO `inventario` (`id_inventario`, `entradas`, `salidas`, `saldo`, `PRODUCTOS_id_producto`, `DETALLE_MOVIMIENTO_id_detalle_movimiento`) VALUES
(64, 500, 0, 500, 0000000012, 62),
(65, 100, 0, 100, 0000000013, 63),
(66, 100, 0, 100, 0000000014, 64),
(67, 10, 0, 10, 0000000015, 65),
(71, 25, 0, 25, 0000000016, 69),
(75, 25, 0, 25, 0000000017, 70),
(76, 0, 2, 23, 0000000017, 71),
(77, 0, 10, 90, 0000000013, 72),
(78, 0, 1, 99, 0000000014, 73),
(79, 0, 1, 9, 0000000015, 74),
(80, 0, 1, 499, 0000000012, 75),
(81, 2, 0, 25, 0000000017, 71),
(82, 10, 0, 100, 0000000013, 72),
(83, 1, 0, 100, 0000000014, 73),
(84, 1, 0, 10, 0000000015, 74),
(85, 1, 0, 500, 0000000012, 75);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `marca_producto`
--

CREATE TABLE `marca_producto` (
  `id_marca_producto` int(11) NOT NULL,
  `nombre_marca_producto` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `marca_producto`
--

INSERT INTO `marca_producto` (`id_marca_producto`, `nombre_marca_producto`) VALUES
(1, 'Norma'),
(2, 'Pelikan'),
(3, 'Estilo'),
(4, 'Esika');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `movimiento`
--

CREATE TABLE `movimiento` (
  `id_movimiento` int(11) NOT NULL,
  `numero_de_documento` varchar(50) NOT NULL,
  `fecha` varchar(10) NOT NULL,
  `subtotal` float NOT NULL,
  `total_iva` float NOT NULL,
  `total_factura` float NOT NULL,
  `FORMAS_DE_PAGO_id_forma_de_pago` int(11) NOT NULL,
  `TIPO_DE_DOCUMENTO_CONTABLE_id_tipo_de_documento_contable` int(11) NOT NULL,
  `CLIENTES_idCliente` int(11) NOT NULL,
  `estado_movimiento` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `movimiento`
--

INSERT INTO `movimiento` (`id_movimiento`, `numero_de_documento`, `fecha`, `subtotal`, `total_iva`, `total_factura`, `FORMAS_DE_PAGO_id_forma_de_pago`, `TIPO_DE_DOCUMENTO_CONTABLE_id_tipo_de_documento_contable`, `CLIENTES_idCliente`, `estado_movimiento`) VALUES
(54, 'Inicio 12', '2021-08-11', 0, 0, 0, 1, 1, 1, 3),
(55, 'Inicio 13', '2021-08-11', 0, 0, 0, 1, 1, 1, 3),
(56, 'Inicio 14', '2021-08-11', 0, 0, 0, 1, 1, 1, 3),
(57, 'Inicio 15', '2021-09-11', 0, 0, 0, 1, 1, 1, 3),
(60, 'Inicio 16', '2021-09-11', 0, 0, 0, 1, 1, 1, 3),
(61, 'Inicio 17', '2021-09-11', 0, 0, 0, 1, 1, 1, 3),
(62, '100', '2021-09-11', 190865, 29134.8, 220000, 1, 1, 1, 2),
(63, '101', '2021-09-11', 44537.8, 8462.19, 53000, 1, 1, 1, 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `id_producto` int(10) UNSIGNED ZEROFILL NOT NULL,
  `identificacion_producto` varchar(45) NOT NULL,
  `nombre_producto` varchar(50) NOT NULL,
  `precio_producto` double NOT NULL,
  `descripcion_producto` varchar(50) NOT NULL,
  `cantidad_producto` int(3) NOT NULL,
  `iva_producto` int(7) NOT NULL,
  `PROVEEDORES_id_proveedor` int(11) NOT NULL,
  `CATEGORIA_PRODUCTO_id_categoria_producto` int(11) NOT NULL,
  `ESTADO_PRODUCTO_id_estado_producto` int(11) NOT NULL,
  `MARCA_PRODUCTO_id_marca_producto` int(11) NOT NULL,
  `UNIDAD_DE_MEDIDA_PRODUCTO_id_unidad_de_medida_producto` int(11) NOT NULL,
  `imagen_producto` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`id_producto`, `identificacion_producto`, `nombre_producto`, `precio_producto`, `descripcion_producto`, `cantidad_producto`, `iva_producto`, `PROVEEDORES_id_proveedor`, `CATEGORIA_PRODUCTO_id_categoria_producto`, `ESTADO_PRODUCTO_id_estado_producto`, `MARCA_PRODUCTO_id_marca_producto`, `UNIDAD_DE_MEDIDA_PRODUCTO_id_unidad_de_medida_producto`, `imagen_producto`) VALUES
(0000000012, '1100', 'Cuaderno', 5000, 'Cuaderno 100 Hojas', 500, 19, 2, 1, 1, 1, 1, '../imagenes/notepad-932864_1280.jpg'),
(0000000013, '1102', 'Lapices', 15000, 'Lapices Norma', 100, 19, 3, 3, 1, 3, 1, '../imagenes/lapizcolor.jpg'),
(0000000014, '11023', 'Marcadores', 25000, 'Marcadores Norma', 100, 19, 2, 4, 1, 1, 1, '../imagenes/marcadornorma.jpg'),
(0000000015, '20145', 'Calculadora', 23000, 'Calculadora Casio 6514', 10, 19, 2, 1, 1, 1, 1, '../imagenes/calculator-178127_1280.jpg'),
(0000000016, '100023', 'Borrador', 1500, 'Borrador Pelikan', 25, 19, 2, 1, 1, 1, 1, '../imagenes/eraser-3822402_1920.jpg'),
(0000000017, '11254422', 'Mochila', 35000, 'Mochila Escolar', 25, 8, 2, 1, 1, 1, 1, '../imagenes/imagenunouno.jpg');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proveedores`
--

CREATE TABLE `proveedores` (
  `id_proveedor` int(11) NOT NULL,
  `identificacion_proveedor` varchar(50) NOT NULL,
  `nombre_proveedor` varchar(50) NOT NULL,
  `correo_proveedor` varchar(50) NOT NULL,
  `direccion_proveedor` varchar(50) NOT NULL,
  `telefono_1_proveedor` varchar(20) NOT NULL,
  `telefono_2_proveedor` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `proveedores`
--

INSERT INTO `proveedores` (`id_proveedor`, `identificacion_proveedor`, `nombre_proveedor`, `correo_proveedor`, `direccion_proveedor`, `telefono_1_proveedor`, `telefono_2_proveedor`) VALUES
(2, '1', 'Distrtibuidores Norma', 'a@a.com', 'Piedecuesta', '3024773079', '3024773079'),
(3, '2', 'Distribuidores Pelikan', 'b@b.com', 'Bucaramanga', '1', '2');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo_de_documento_contable`
--

CREATE TABLE `tipo_de_documento_contable` (
  `id_tipo_de_documento_contable` int(11) NOT NULL,
  `codigo` varchar(15) NOT NULL,
  `descripcion` varchar(20) NOT NULL,
  `naturaleza` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `tipo_de_documento_contable`
--

INSERT INTO `tipo_de_documento_contable` (`id_tipo_de_documento_contable`, `codigo`, `descripcion`, `naturaleza`) VALUES
(1, '1', 'Factura', 'Contable'),
(2, '2', 'Factura Electrónica', 'Contable'),
(3, '3', 'Nota de Venta', 'Contable');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo_doc_identificacion_usuario`
--

CREATE TABLE `tipo_doc_identificacion_usuario` (
  `id_doc_identificacion_usuario` int(11) NOT NULL,
  `tipo_doc_identificacion_usuario` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `tipo_doc_identificacion_usuario`
--

INSERT INTO `tipo_doc_identificacion_usuario` (`id_doc_identificacion_usuario`, `tipo_doc_identificacion_usuario`) VALUES
(1, 'Cédula');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo_usuario`
--

CREATE TABLE `tipo_usuario` (
  `id_tipo_usuario` int(11) NOT NULL,
  `descripcion_tipo_usuario` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `tipo_usuario`
--

INSERT INTO `tipo_usuario` (`id_tipo_usuario`, `descripcion_tipo_usuario`) VALUES
(1, 'Administrador'),
(2, 'Usuario');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `unidad_de_medida_producto`
--

CREATE TABLE `unidad_de_medida_producto` (
  `id_unidad_de_medida_producto` int(11) NOT NULL,
  `descripcion_unidad_de_medida_producto` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `unidad_de_medida_producto`
--

INSERT INTO `unidad_de_medida_producto` (`id_unidad_de_medida_producto`, `descripcion_unidad_de_medida_producto`) VALUES
(1, 'Unidad'),
(2, 'Decenas'),
(3, 'Docenas');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id_usuario` int(11) NOT NULL,
  `nombres_usuario` varchar(50) NOT NULL,
  `apellidos_usuario` varchar(50) NOT NULL,
  `identificacion_usuario` varchar(50) NOT NULL,
  `clave` varchar(100) NOT NULL,
  `telefono_usuario` varchar(20) NOT NULL,
  `direccion_usuario` varchar(50) NOT NULL,
  `correo_usuario` varchar(50) DEFAULT NULL,
  `TIPO_USUARIO_id_tipo_usuario` int(11) NOT NULL,
  `ESTADO_USUARIO_id_estado_usuario` int(11) NOT NULL,
  `GENERO_USUARIO_id_genero_usuario` int(11) NOT NULL,
  `TIPO_DOC_IDENTIFICACION_USUARIO_id_doc_identificacion_usuario` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id_usuario`, `nombres_usuario`, `apellidos_usuario`, `identificacion_usuario`, `clave`, `telefono_usuario`, `direccion_usuario`, `correo_usuario`, `TIPO_USUARIO_id_tipo_usuario`, `ESTADO_USUARIO_id_estado_usuario`, `GENERO_USUARIO_id_genero_usuario`, `TIPO_DOC_IDENTIFICACION_USUARIO_id_doc_identificacion_usuario`) VALUES
(4, 'Usuario', 'Administrador', '11', 'kzAUZ4uwD20=', '12345678', 'aa', 'a@a.com', 1, 1, 1, 1),
(5, 'Carlitos', 'Way', '12345', 'tU0t2UqZjlg=', '1', '1', 'a@a.com', 2, 1, 1, 1),
(13, 'Pedro', 'Cajas', '123456', 'zZBIyVH+CYo=', '1', '1', 'a@a.com', 1, 1, 1, 1);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `categoria_producto`
--
ALTER TABLE `categoria_producto`
  ADD PRIMARY KEY (`id_categoria_producto`);

--
-- Indices de la tabla `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`idCliente`),
  ADD KEY `fk_CLIENTES_USUARIOS1_idx` (`USUARIOS_id_usuario`);

--
-- Indices de la tabla `detalle_movimiento`
--
ALTER TABLE `detalle_movimiento`
  ADD PRIMARY KEY (`id_detalle_movimiento`),
  ADD KEY `fk_DETALLE_MOVIMIENTO_PRODUCTOS1_idx` (`PRODUCTOS_id_producto`),
  ADD KEY `fk_DETALLE_MOVIMIENTO_MOVIMIENTO1_idx` (`MOVIMIENTO_id_movimiento`);

--
-- Indices de la tabla `estado_producto`
--
ALTER TABLE `estado_producto`
  ADD PRIMARY KEY (`id_estado_producto`);

--
-- Indices de la tabla `estado_usuario`
--
ALTER TABLE `estado_usuario`
  ADD PRIMARY KEY (`id_estado_usuario`);

--
-- Indices de la tabla `formas_de_pago`
--
ALTER TABLE `formas_de_pago`
  ADD PRIMARY KEY (`id_forma_de_pago`);

--
-- Indices de la tabla `genero_usuario`
--
ALTER TABLE `genero_usuario`
  ADD PRIMARY KEY (`id_genero_usuario`);

--
-- Indices de la tabla `inventario`
--
ALTER TABLE `inventario`
  ADD PRIMARY KEY (`id_inventario`),
  ADD KEY `fk_INVENTARIO_PRODUCTOS1_idx` (`PRODUCTOS_id_producto`),
  ADD KEY `fk_INVENTARIO_DETALLE_MOVIMIENTO1_idx` (`DETALLE_MOVIMIENTO_id_detalle_movimiento`);

--
-- Indices de la tabla `marca_producto`
--
ALTER TABLE `marca_producto`
  ADD PRIMARY KEY (`id_marca_producto`);

--
-- Indices de la tabla `movimiento`
--
ALTER TABLE `movimiento`
  ADD PRIMARY KEY (`id_movimiento`),
  ADD KEY `CLIENTES_idCliente` (`CLIENTES_idCliente`),
  ADD KEY `movimiento_ibfk_2` (`TIPO_DE_DOCUMENTO_CONTABLE_id_tipo_de_documento_contable`),
  ADD KEY `movimiento_ibfk_1` (`FORMAS_DE_PAGO_id_forma_de_pago`);

--
-- Indices de la tabla `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`id_producto`),
  ADD KEY `fk_PRODUCTOS_PROVEEDORES1_idx` (`PROVEEDORES_id_proveedor`),
  ADD KEY `fk_PRODUCTOS_CATEGORIA_PRODUCTO1_idx` (`CATEGORIA_PRODUCTO_id_categoria_producto`),
  ADD KEY `fk_PRODUCTOS_ESTADO_PRODUCTO1_idx` (`ESTADO_PRODUCTO_id_estado_producto`),
  ADD KEY `fk_PRODUCTOS_MARCA_PRODUCTO1_idx` (`MARCA_PRODUCTO_id_marca_producto`),
  ADD KEY `fk_PRODUCTOS_UNIDAD_DE_MEDIDA_PRODUCTO1_idx` (`UNIDAD_DE_MEDIDA_PRODUCTO_id_unidad_de_medida_producto`);

--
-- Indices de la tabla `proveedores`
--
ALTER TABLE `proveedores`
  ADD PRIMARY KEY (`id_proveedor`);

--
-- Indices de la tabla `tipo_de_documento_contable`
--
ALTER TABLE `tipo_de_documento_contable`
  ADD PRIMARY KEY (`id_tipo_de_documento_contable`);

--
-- Indices de la tabla `tipo_doc_identificacion_usuario`
--
ALTER TABLE `tipo_doc_identificacion_usuario`
  ADD PRIMARY KEY (`id_doc_identificacion_usuario`);

--
-- Indices de la tabla `tipo_usuario`
--
ALTER TABLE `tipo_usuario`
  ADD PRIMARY KEY (`id_tipo_usuario`);

--
-- Indices de la tabla `unidad_de_medida_producto`
--
ALTER TABLE `unidad_de_medida_producto`
  ADD PRIMARY KEY (`id_unidad_de_medida_producto`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id_usuario`),
  ADD UNIQUE KEY `identificacionUsuario_UNIQUE` (`identificacion_usuario`),
  ADD KEY `fk_USUARIOS_TIPO_USUARIO1_idx` (`TIPO_USUARIO_id_tipo_usuario`),
  ADD KEY `fk_USUARIOS_ESTADO_USUARIO1_idx` (`ESTADO_USUARIO_id_estado_usuario`),
  ADD KEY `fk_USUARIOS_GENERO_USUARIO1_idx` (`GENERO_USUARIO_id_genero_usuario`),
  ADD KEY `fk_USUARIOS_TIPO_DOC_IDENTIFICACION_USUARIO1_idx` (`TIPO_DOC_IDENTIFICACION_USUARIO_id_doc_identificacion_usuario`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `categoria_producto`
--
ALTER TABLE `categoria_producto`
  MODIFY `id_categoria_producto` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `clientes`
--
ALTER TABLE `clientes`
  MODIFY `idCliente` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `detalle_movimiento`
--
ALTER TABLE `detalle_movimiento`
  MODIFY `id_detalle_movimiento` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=76;

--
-- AUTO_INCREMENT de la tabla `estado_producto`
--
ALTER TABLE `estado_producto`
  MODIFY `id_estado_producto` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `estado_usuario`
--
ALTER TABLE `estado_usuario`
  MODIFY `id_estado_usuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `formas_de_pago`
--
ALTER TABLE `formas_de_pago`
  MODIFY `id_forma_de_pago` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `genero_usuario`
--
ALTER TABLE `genero_usuario`
  MODIFY `id_genero_usuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `inventario`
--
ALTER TABLE `inventario`
  MODIFY `id_inventario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=86;

--
-- AUTO_INCREMENT de la tabla `marca_producto`
--
ALTER TABLE `marca_producto`
  MODIFY `id_marca_producto` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `movimiento`
--
ALTER TABLE `movimiento`
  MODIFY `id_movimiento` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=64;

--
-- AUTO_INCREMENT de la tabla `productos`
--
ALTER TABLE `productos`
  MODIFY `id_producto` int(10) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT de la tabla `proveedores`
--
ALTER TABLE `proveedores`
  MODIFY `id_proveedor` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `tipo_de_documento_contable`
--
ALTER TABLE `tipo_de_documento_contable`
  MODIFY `id_tipo_de_documento_contable` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `tipo_doc_identificacion_usuario`
--
ALTER TABLE `tipo_doc_identificacion_usuario`
  MODIFY `id_doc_identificacion_usuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `tipo_usuario`
--
ALTER TABLE `tipo_usuario`
  MODIFY `id_tipo_usuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `unidad_de_medida_producto`
--
ALTER TABLE `unidad_de_medida_producto`
  MODIFY `id_unidad_de_medida_producto` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id_usuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `clientes`
--
ALTER TABLE `clientes`
  ADD CONSTRAINT `fk_CLIENTES_USUARIOS1` FOREIGN KEY (`USUARIOS_id_usuario`) REFERENCES `usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `detalle_movimiento`
--
ALTER TABLE `detalle_movimiento`
  ADD CONSTRAINT `fk_DETALLE_MOVIMIENTO_MOVIMIENTO1` FOREIGN KEY (`MOVIMIENTO_id_movimiento`) REFERENCES `movimiento` (`id_movimiento`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_DETALLE_MOVIMIENTO_PRODUCTOS1` FOREIGN KEY (`PRODUCTOS_id_producto`) REFERENCES `productos` (`id_producto`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `inventario`
--
ALTER TABLE `inventario`
  ADD CONSTRAINT `fk_INVENTARIO_DETALLE_MOVIMIENTO1` FOREIGN KEY (`DETALLE_MOVIMIENTO_id_detalle_movimiento`) REFERENCES `detalle_movimiento` (`id_detalle_movimiento`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_INVENTARIO_PRODUCTOS1` FOREIGN KEY (`PRODUCTOS_id_producto`) REFERENCES `productos` (`id_producto`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `movimiento`
--
ALTER TABLE `movimiento`
  ADD CONSTRAINT `movimiento_ibfk_1` FOREIGN KEY (`FORMAS_DE_PAGO_id_forma_de_pago`) REFERENCES `formas_de_pago` (`id_forma_de_pago`),
  ADD CONSTRAINT `movimiento_ibfk_2` FOREIGN KEY (`TIPO_DE_DOCUMENTO_CONTABLE_id_tipo_de_documento_contable`) REFERENCES `tipo_de_documento_contable` (`id_tipo_de_documento_contable`),
  ADD CONSTRAINT `movimiento_ibfk_3` FOREIGN KEY (`CLIENTES_idCliente`) REFERENCES `clientes` (`idCliente`);

--
-- Filtros para la tabla `productos`
--
ALTER TABLE `productos`
  ADD CONSTRAINT `fk_PRODUCTOS_CATEGORIA_PRODUCTO1` FOREIGN KEY (`CATEGORIA_PRODUCTO_id_categoria_producto`) REFERENCES `categoria_producto` (`id_categoria_producto`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_PRODUCTOS_ESTADO_PRODUCTO1` FOREIGN KEY (`ESTADO_PRODUCTO_id_estado_producto`) REFERENCES `estado_producto` (`id_estado_producto`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_PRODUCTOS_MARCA_PRODUCTO1` FOREIGN KEY (`MARCA_PRODUCTO_id_marca_producto`) REFERENCES `marca_producto` (`id_marca_producto`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_PRODUCTOS_PROVEEDORES1` FOREIGN KEY (`PROVEEDORES_id_proveedor`) REFERENCES `proveedores` (`id_proveedor`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_PRODUCTOS_UNIDAD_DE_MEDIDA_PRODUCTO1` FOREIGN KEY (`UNIDAD_DE_MEDIDA_PRODUCTO_id_unidad_de_medida_producto`) REFERENCES `unidad_de_medida_producto` (`id_unidad_de_medida_producto`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD CONSTRAINT `fk_USUARIOS_ESTADO_USUARIO1` FOREIGN KEY (`ESTADO_USUARIO_id_estado_usuario`) REFERENCES `estado_usuario` (`id_estado_usuario`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_USUARIOS_GENERO_USUARIO1` FOREIGN KEY (`GENERO_USUARIO_id_genero_usuario`) REFERENCES `genero_usuario` (`id_genero_usuario`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_USUARIOS_TIPO_DOC_IDENTIFICACION_USUARIO1` FOREIGN KEY (`TIPO_DOC_IDENTIFICACION_USUARIO_id_doc_identificacion_usuario`) REFERENCES `tipo_doc_identificacion_usuario` (`id_doc_identificacion_usuario`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_USUARIOS_TIPO_USUARIO1` FOREIGN KEY (`TIPO_USUARIO_id_tipo_usuario`) REFERENCES `tipo_usuario` (`id_tipo_usuario`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
