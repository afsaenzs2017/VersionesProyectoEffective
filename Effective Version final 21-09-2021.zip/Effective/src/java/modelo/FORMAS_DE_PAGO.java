package modelo;

/**
 *
 * @author AndresSossa
 */
public class FORMAS_DE_PAGO {

    private String id_forma_de_pago;
    private String tipo_de_pago;

    public String getId_forma_de_pago() {
        return id_forma_de_pago;
    }

    public void setId_forma_de_pago(String id_forma_de_pago) {
        this.id_forma_de_pago = id_forma_de_pago;
    }

    public String getTipo_de_pago() {
        return tipo_de_pago;
    }

    public void setTipo_de_pago(String tipo_de_pago) {
        this.tipo_de_pago = tipo_de_pago;
    }

}
