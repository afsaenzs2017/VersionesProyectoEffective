package modelo;

/**
 *
 * @author AndresSaenz
 */
public class TIPO_DOC_IDENTIFICACION_USUARIO {

    private String id_doc_identificacion_usuario;
    private String tipo_doc_identificacion_usuario;

    public String getId_doc_identificacion_usuario() {
        return id_doc_identificacion_usuario;
    }

    public void setId_doc_identificacion_usuario(String id_doc_identificacion_usuario) {
        this.id_doc_identificacion_usuario = id_doc_identificacion_usuario;
    }

    public String getTipo_doc_identificacion_usuario() {
        return tipo_doc_identificacion_usuario;
    }

    public void setTipo_doc_identificacion_usuario(String tipo_doc_identificacion_usuario) {
        this.tipo_doc_identificacion_usuario = tipo_doc_identificacion_usuario;
    }

}
