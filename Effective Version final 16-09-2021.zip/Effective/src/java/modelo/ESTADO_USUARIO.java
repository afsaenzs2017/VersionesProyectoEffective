
package modelo;

/**
 *
 * @author AndresSaenz
 */
public class ESTADO_USUARIO {
    
    private String id_estado_usuario;
    private String descripcion_estado_usuario;

    public String getId_estado_usuario() {
        return id_estado_usuario;
    }

    public void setId_estado_usuario(String id_estado_usuario) {
        this.id_estado_usuario = id_estado_usuario;
    }

    public String getDescripcion_estado_usuario() {
        return descripcion_estado_usuario;
    }

    public void setDescripcion_estado_usuario(String descripcion_estado_usuario) {
        this.descripcion_estado_usuario = descripcion_estado_usuario;
    }
       
}
