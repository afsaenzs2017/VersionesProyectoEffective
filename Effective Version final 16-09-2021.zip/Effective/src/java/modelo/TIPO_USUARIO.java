
package modelo;

/**
 *
 * @author AndresSaenz
 */
public class TIPO_USUARIO {
    
    private String id_tipo_usuario;
    private String descripcion_tipo_usuario;

    public String getId_tipo_usuario() {
        return id_tipo_usuario;
    }

    public void setId_tipo_usuario(String id_tipo_usuario) {
        this.id_tipo_usuario = id_tipo_usuario;
    }

    public String getDescripcion_tipo_usuario() {
        return descripcion_tipo_usuario;
    }

    public void setDescripcion_tipo_usuario(String descripcion_tipo_usuario) {
        this.descripcion_tipo_usuario = descripcion_tipo_usuario;
    }
    
  

   
    
  
    
    
}
