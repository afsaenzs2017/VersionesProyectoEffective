
package modelo;

/**
 *
 * @author YesidValencia
 */
public class PROVEEDORES {
    
    private int id_proveedor;
    private String identificacion_proveedor;
    private String nombre_proveedor;
    private String correo_proveedor ;
    private String direccion_proveedor;
    private String telefono_1_proveedor ;
    private String telefono_2_proveedor;
    

    public int getId_proveedor() {
        return id_proveedor;
    }

    public void setId_proveedor(int id_proveedor) {
        this.id_proveedor = id_proveedor;
    }

    public String getIdentificacion_proveedor() {
        return identificacion_proveedor;
    }

    public void setIdentificacion_proveedor(String identificacion_proveedor) {
        this.identificacion_proveedor = identificacion_proveedor;
    }

    public String getNombre_proveedor() {
        return nombre_proveedor;
    }

    public void setNombre_proveedor(String nombre_proveedor) {
        this.nombre_proveedor = nombre_proveedor;
    }

    public String getCorreo_proveedor() {
        return correo_proveedor;
    }

    public void setCorreo_proveedor(String correo_proveedor) {
        this.correo_proveedor = correo_proveedor;
    }

    public String getDireccion_proveedor() {
        return direccion_proveedor;
    }

    public void setDireccion_proveedor(String direccion_proveedor) {
        this.direccion_proveedor = direccion_proveedor;
    }

    public String getTelefono_1_proveedor() {
        return telefono_1_proveedor;
    }

    public void setTelefono_1_proveedor(String telefono_1_proveedor) {
        this.telefono_1_proveedor = telefono_1_proveedor;
    }

    public String getTelefono_2_proveedor() {
        return telefono_2_proveedor;
    }

    public void setTelefono_2_proveedor(String telefono_2_proveedor) {
        this.telefono_2_proveedor = telefono_2_proveedor;
    }
    
   

  
     
}
