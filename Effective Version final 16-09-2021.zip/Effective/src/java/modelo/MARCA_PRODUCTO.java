

package modelo;

/**
 *
 * @author LadyChitivo
 */
public class MARCA_PRODUCTO {
    
    private String id_marca_producto;
    private String nombre_marca_producto;

    public String getId_marca_producto() {
        return id_marca_producto;
    }

    public void setId_marca_producto(String id_marca_producto) {
        this.id_marca_producto = id_marca_producto;
    }

    public String getNombre_marca_producto() {
        return nombre_marca_producto;
    }

    public void setNombre_marca_producto(String nombre_marca_producto) {
        this.nombre_marca_producto = nombre_marca_producto;
    }

 
 
    
}
