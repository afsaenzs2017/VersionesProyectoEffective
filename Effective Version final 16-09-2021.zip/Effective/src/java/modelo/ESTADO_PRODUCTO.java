
package modelo;

/**
 *
 * @author LadyChitivo
 */
public class ESTADO_PRODUCTO {
    
    private String id_estado_producto;
    private String descripcion_estado_producto ;

    public String getId_estado_producto() {
        return id_estado_producto;
    }

    public void setId_estado_producto(String id_estado_producto) {
        this.id_estado_producto = id_estado_producto;
    }

    public String getDescripcion_estado_producto() {
        return descripcion_estado_producto;
    }

    public void setDescripcion_estado_producto(String descripcion_estado_producto) {
        this.descripcion_estado_producto = descripcion_estado_producto;
    }

 
    
}
